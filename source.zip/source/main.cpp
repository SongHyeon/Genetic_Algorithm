#include "..\header\common.h"
#include "..\header\bitmap.h"
#include "..\header\Genetic_Algorithm.h"

Genetic_Algorithm GA;

int main(){
	GA.start("panda.dib");
	return 0;
}
